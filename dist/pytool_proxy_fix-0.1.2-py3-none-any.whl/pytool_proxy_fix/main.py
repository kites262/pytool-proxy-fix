def main_fix_urllib():
    """修复 urllib bug """
    from pytool_proxy_fix.fix_urllib_https import main as fix_urllib
    fix_urllib()
